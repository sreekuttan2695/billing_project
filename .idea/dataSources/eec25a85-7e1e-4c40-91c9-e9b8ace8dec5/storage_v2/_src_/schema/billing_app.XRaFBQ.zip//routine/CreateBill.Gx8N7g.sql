create
    definer = root@localhost procedure CreateBill(IN client_id int, IN customer_id int, IN invoice_date date,
                                                  IN place_of_supply varchar(255),
                                                  IN total_amount_before_tax decimal(10, 2), IN discount decimal(10, 2),
                                                  IN total_amount decimal(10, 2), IN status varchar(255),
                                                  IN is_rcm tinyint(1), IN created_by varchar(255), INOUT bill_id int,
                                                  IN bill_items json, IN bill_tax_splits json)
BEGIN
    DECLARE new_invoice_no VARCHAR(10);
    DECLARE item JSON;
    DECLARE i INT DEFAULT 0;
    DECLARE tax_split JSON;

    -- Start Transaction
    -- START TRANSACTION;

    -- Generate invoice_no
    SET new_invoice_no = (
        SELECT SUBSTRING(
            CONCAT(
                CONV(FLOOR(RAND() * 100000000), 10, 36), 
                UPPER(CONV(FLOOR(RAND() * 100000000), 10, 36))
            ), 
            1, 10
        )
    );

    -- Insert into Customer_Bill
    INSERT INTO billing_app_customerbill (
        customer_id, client_id, invoice_no, invoice_date, place_of_supply,
        total_amount_before_tax, discount, total_amount, status, is_rcm,
        created_on, created_by, last_updated_on, last_updated_by
    ) VALUES (
        customer_id, client_id, new_invoice_no, invoice_date, place_of_supply,
        total_amount_before_tax, discount, total_amount, status, is_rcm,
        NOW(), created_by, NOW(), created_by
    );

    -- Get the generated bill_id
    SET bill_id = LAST_INSERT_ID();

    -- Insert into Bill_Items
    
    
    WHILE i < JSON_LENGTH(bill_items) DO
        SET item = JSON_EXTRACT(bill_items, CONCAT('$[', i, ']'));
        INSERT INTO billing_app_billitem (
            bill_id, client_id, product_id, qty, unit, price, discount, tax_rate,
            taxable_amount, total_amount, created_on, created_by, last_updated_on, last_updated_by
        ) VALUES (
            bill_id,
            client_id,
            JSON_UNQUOTE(JSON_EXTRACT(item, '$.product_id')),
            JSON_UNQUOTE(JSON_EXTRACT(item, '$.qty')),
            JSON_UNQUOTE(JSON_EXTRACT(item, '$.unit')),
            JSON_UNQUOTE(JSON_EXTRACT(item, '$.price')),
            JSON_UNQUOTE(JSON_EXTRACT(item, '$.discount')),
            JSON_UNQUOTE(JSON_EXTRACT(item, '$.tax_rate')),
            JSON_UNQUOTE(JSON_EXTRACT(item, '$.taxable_amount')),
            JSON_UNQUOTE(JSON_EXTRACT(item, '$.total_amount')),
            NOW(), created_by, NOW(), created_by
        );
        SET i = i + 1;
    END WHILE;

    -- Insert into Bill_Tax_Splits
    
    SET i = 0;
    WHILE i < JSON_LENGTH(bill_tax_splits) DO
        SET tax_split = JSON_EXTRACT(bill_tax_splits, CONCAT('$[', i, ']'));
        INSERT INTO billing_app_billtaxsplit (
            bill_id, tax_rate, SGST, CGST, IGST, CESS, 
            created_on, created_by, last_updated_on, last_updated_by
        ) VALUES (
            bill_id,
            JSON_UNQUOTE(JSON_EXTRACT(tax_split, '$.tax_rate')),
            JSON_UNQUOTE(JSON_EXTRACT(tax_split, '$.SGST')),
            JSON_UNQUOTE(JSON_EXTRACT(tax_split, '$.CGST')),
            JSON_UNQUOTE(JSON_EXTRACT(tax_split, '$.IGST')),
            JSON_UNQUOTE(JSON_EXTRACT(tax_split, '$.CESS')),
            NOW(), created_by, NOW(), created_by
        );
        SET i = i + 1;
    END WHILE;

    -- Commit Transaction
    -- COMMIT;
END;

